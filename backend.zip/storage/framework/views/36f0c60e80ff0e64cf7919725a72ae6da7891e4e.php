<!DOCTYPE html>
<html>
<head>
    <title>Verify Your Email</title>
</head>
<body>
    <h1>Verify Your Email Address</h1>
    <p>Please click the button below to verify your email address.</p>
    <a href="<?php echo e($verificationUrl); ?>" style="display: inline-block; padding: 10px 20px; margin: 10px 0; font-size: 16px; color: white; background-color: #28a745; text-decoration: none;">Verify Email</a>
</body>
</html><?php /**PATH C:\backend\resources\views/emails/verification_code.blade.php ENDPATH**/ ?>