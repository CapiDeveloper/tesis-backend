<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Restablecer Contraseña</title>
</head>
<body>
    <h1>Restablecer Contraseña</h1>
    <p>Haga click en el siguiente boton para restablecer su contraseña:</p>
    <a href="<?php echo e(env('APP_FRONTEND_URL')); ?><?php echo e($url); ?>" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-align: center; text-decoration: none; display: inline-block; border-radius: 4px;">
        Reset Password
    </a>
</body>
</html><?php /**PATH C:\backend\resources\views/emails/restablecer-clave.blade.php ENDPATH**/ ?>